﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace ProyectoFinalProgramacion1
{
    public partial class Productos : Form
    {
        public Productos()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void Productos_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = llenar_grid();
        }

      
        private void button1_Click(object sender, EventArgs e)
        {
            loginconexion.Open();
            string insertar = "INSERT INTO productos(nombre,marca,precio,stock)VALUES(@nombre,@marca,@precio,@stock)";
            MySqlCommand cmd = new MySqlCommand(insertar, loginconexion);

            cmd.Parameters.AddWithValue("@nombre", txtgnombre.Text);
            cmd.Parameters.AddWithValue("@marca", txtgmarca.Text);
            cmd.Parameters.AddWithValue("@precio", txtgprecio.Text);
            cmd.Parameters.AddWithValue("@stock",txtgstock.Text);
            cmd.ExecuteNonQuery();

            loginconexion.Close();

            MessageBox.Show("Se agregó correctamente");
            txtgnombre.Text = "NOMBRE";
            txtgmarca.Text = "MARCA";
            txtgprecio.Text = "PRECIO";
            txtgstock.Text = "STOCK";

            dataGridView1.DataSource = llenar_grid();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            loginconexion.Open();
            string queryupdate = "UPDATE productos SET nombre=@nombre,marca=@marca,precio=@precio,stock=@stock WHERE nombre=@nombre";
            MySqlCommand cmd = new MySqlCommand(queryupdate, loginconexion);
            cmd.Parameters.AddWithValue("@nombre", txtgnombre.Text);
            cmd.Parameters.AddWithValue("@marca", txtgmarca.Text);
            cmd.Parameters.AddWithValue("@precio", txtgprecio.Text);
            cmd.Parameters.AddWithValue("@stock", txtgstock.Text);

            cmd.ExecuteNonQuery();

            loginconexion.Close();

            MessageBox.Show("Modificaciòn existosa");

            dataGridView1.DataSource = llenar_grid();
            txtgnombre.Text = "NOMBRE";
            txtgmarca.Text = "MARCA";
            txtgprecio.Text = "PRECIO";
            txtgstock.Text = "STOCK";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            loginconexion.Open();
            string eliminar = "DELETE FROM productos WHERE nombre=@nombre";
            MySqlCommand cmd = new MySqlCommand(eliminar, loginconexion);
            cmd.Parameters.AddWithValue("@nombre", txtgnombre.Text);
            cmd.Parameters.AddWithValue("@marca", txtgmarca.Text);
            cmd.Parameters.AddWithValue("@precio", txtgprecio.Text);
            cmd.Parameters.AddWithValue("@stock", txtgstock.Text);

            cmd.ExecuteNonQuery();
            loginconexion.Close();

            MessageBox.Show("Eliminación exitosa");

            dataGridView1.DataSource = llenar_grid();

            txtgnombre.Text = "NOMBRE";
            txtgmarca.Text = "MARCA";
            txtgprecio.Text = "PRECIO";
            txtgstock.Text = "STOCK";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Inicio home = new Inicio();
            home.Show();
            this.Hide();
        }
        static string conexion = "SERVER=127.0.0.1;PORT=3306;DATABASE=producdatabase;UID=root;PASWORD=;";
        MySqlConnection loginconexion = new MySqlConnection(conexion);

        public DataTable llenar_grid()
        {
            loginconexion.Open();
            DataTable dt = new DataTable();
            string llenar = "select nombre, marca, precio, stock from productos";
            MySqlCommand cmd = new MySqlCommand(llenar, loginconexion);
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            da.Fill(dt);
            loginconexion.Close();

            return dt;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                txtgnombre.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
                txtgmarca.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
                txtgprecio.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
                txtgstock.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
            }
            catch
            {

            }
        }

        private void txtgnombre_Enter(object sender, EventArgs e)
        {
            if (txtgnombre.Text == "NOMBRE")
            {
                txtgnombre.Text = "";
            }
        }

        private void txtgnombre_Leave(object sender, EventArgs e)
        {
            if (txtgnombre.Text == "")
            {
                txtgnombre.Text = "NOMBRE";
            }
        }

        private void txtgmarca_Enter(object sender, EventArgs e)
        {
            if (txtgmarca.Text == "MARCA")
            {
                txtgmarca.Text = "";
            }
        }

        private void txtgmarca_Leave(object sender, EventArgs e)
        {
            if (txtgmarca.Text == "")
            {
                txtgmarca.Text = "MARCA";
            }
        }

        private void txtgprecio_Enter(object sender, EventArgs e)
        {
            if (txtgprecio.Text == "PRECIO")
            {
                txtgprecio.Text = "";
            }
        }

        private void txtgprecio_Leave(object sender, EventArgs e)
        {
            if (txtgprecio.Text == "")
            {
                txtgprecio.Text = "PRECIO";
            }
        }

        private void txtgstock_Enter(object sender, EventArgs e)
        {
            if (txtgstock.Text == "STOCK")
            {
                txtgstock.Text = "";
            }
        }

        private void txtgstock_Leave(object sender, EventArgs e)
        {
            if (txtgstock.Text == "")
            {
                txtgstock.Text = "STOCK";
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            loginconexion.Open();
            string queryinsertar = "INSERT INTO productos(nombre,marca,precio,stock)VALUES(@nombre,@marca,@precio,@stock)";
            MySqlCommand cmd = new MySqlCommand(queryinsertar, loginconexion);
            cmd.Parameters.AddWithValue("@nombre", txtgnombre.Text);
            cmd.Parameters.AddWithValue("@marca", txtgmarca.Text);
            cmd.Parameters.AddWithValue("@precio", txtgprecio.Text);
            cmd.Parameters.AddWithValue("@stock", txtgstock.Text);

            cmd.ExecuteNonQuery();
            loginconexion.Close();

            MessageBox.Show("Se ha agregado el producto correcatemente");

            dataGridView1.DataSource = llenar_grid();

            txtgnombre.Text = "NOMBRE";
            txtgmarca.Text = "MARCA";
            txtgprecio.Text = "PRECIO";
            txtgstock.Text = "STOCK";
        }
    }
}
