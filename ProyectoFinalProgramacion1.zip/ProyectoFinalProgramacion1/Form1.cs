﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace ProyectoFinalProgramacion1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        private void label2_Click(object sender, EventArgs e)
        {

        }
        static string conexion = "SERVER=127.0.0.1;PORT=3306;DATABASE=userdatabase;UID=root;PASWORD=;";
        MySqlConnection loginconexion = new MySqlConnection(conexion);
        public void Login()
        {
            string query = "SELECT * FROM userdatabase.usuarios WHERE usuario=@usuario AND contraseña=@contraseña";
            MySqlCommand cmd = new MySqlCommand(query, loginconexion);
            cmd.Parameters.AddWithValue("@usuario", txtususario.Text);
            cmd.Parameters.AddWithValue("@contraseña", txtpass.Text);
            MySqlDataReader reader;
            try
            {
                loginconexion.Open();
                reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read()) {
                        {
                            Inicio home = new Inicio();
                            home.Show();
                            this.Hide();
                        } }
                }
                else
                {
                    MessageBox.Show("Error intente nuevamente");
                    txtpass.Text = "CONTRASEÑA";
                    txtpass.UseSystemPasswordChar = false;
                }
                loginconexion.Close();
            }
            catch(Exception Error)
            {
                MessageBox.Show(Error.Message);

            }

        }

        private void txtususario_Enter(object sender, EventArgs e)
        {
            if (txtususario.Text == "USUARIO")
            {
                txtususario.Text = "";
            }

        }

        private void txtpass_TextChanged(object sender, EventArgs e)
        {

        }
        
        private void txtususario_Leave(object sender, EventArgs e)
        {
            if (txtususario.Text == "")
            {
                txtususario.Text = "USUARIO";
            }
        }

        private void txtpass_Enter(object sender, EventArgs e)
        {
            if (txtpass.Text == "CONTRASEÑA")
            {
                txtpass.Text = "";
                txtpass.UseSystemPasswordChar = true;
            }
        }

        private void txtpass_Leave(object sender, EventArgs e)
        {
            if (txtpass.Text == "")
            {
                txtpass.Text = "CONTRASEÑA";
                txtpass.UseSystemPasswordChar = false;

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(txtpass.Text==""|| txtususario.Text == "")
            {
                MessageBox.Show("Campos vacíos, favor llenarlos");
                txtususario.Text = "USUARIO";
                txtpass.Text = "CONTRASEÑA";
            }
            else
            {
                Login();
            }
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Registro registrar = new Registro();
            registrar.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }
    }
}
