﻿
namespace ProyectoFinalProgramacion1
{
    partial class Registro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txtrconficontraseña = new System.Windows.Forms.TextBox();
            this.txtrcontraseña = new System.Windows.Forms.TextBox();
            this.txtrusuario = new System.Windows.Forms.TextBox();
            this.txtrnombre = new System.Windows.Forms.TextBox();
            this.txtremail = new System.Windows.Forms.TextBox();
            this.txtrapellido = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnminimizar = new System.Windows.Forms.PictureBox();
            this.btncerrar = new System.Windows.Forms.PictureBox();
            this.txtrtelef = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.btnminimizar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btncerrar)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.ForeColor = System.Drawing.Color.LightGray;
            this.button1.Location = new System.Drawing.Point(328, 493);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(211, 31);
            this.button1.TabIndex = 24;
            this.button1.Text = "VOLVER";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            this.button2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.ForeColor = System.Drawing.Color.LightGray;
            this.button2.Location = new System.Drawing.Point(220, 441);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(408, 46);
            this.button2.TabIndex = 23;
            this.button2.Text = "REGISTRATE";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DimGray;
            this.label1.Location = new System.Drawing.Point(353, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(195, 40);
            this.label1.TabIndex = 22;
            this.label1.Text = "REGISTRATE";
            // 
            // txtrconficontraseña
            // 
            this.txtrconficontraseña.BackColor = System.Drawing.Color.Black;
            this.txtrconficontraseña.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtrconficontraseña.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtrconficontraseña.ForeColor = System.Drawing.Color.DimGray;
            this.txtrconficontraseña.Location = new System.Drawing.Point(206, 371);
            this.txtrconficontraseña.Name = "txtrconficontraseña";
            this.txtrconficontraseña.Size = new System.Drawing.Size(356, 25);
            this.txtrconficontraseña.TabIndex = 21;
            this.txtrconficontraseña.Text = "CONFIRMAR CONTRASEÑA";
            this.txtrconficontraseña.UseWaitCursor = true;
            this.txtrconficontraseña.Enter += new System.EventHandler(this.txtrconficontraseña_Enter);
            this.txtrconficontraseña.Leave += new System.EventHandler(this.txtrconficontraseña_Leave);
            // 
            // txtrcontraseña
            // 
            this.txtrcontraseña.BackColor = System.Drawing.Color.Black;
            this.txtrcontraseña.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtrcontraseña.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtrcontraseña.ForeColor = System.Drawing.Color.DimGray;
            this.txtrcontraseña.Location = new System.Drawing.Point(206, 315);
            this.txtrcontraseña.Name = "txtrcontraseña";
            this.txtrcontraseña.Size = new System.Drawing.Size(167, 25);
            this.txtrcontraseña.TabIndex = 20;
            this.txtrcontraseña.Text = "CONTRASEÑA";
            this.txtrcontraseña.UseWaitCursor = true;
            this.txtrcontraseña.Enter += new System.EventHandler(this.txtrcontraseña_Enter);
            this.txtrcontraseña.Leave += new System.EventHandler(this.txtrcontraseña_Leave);
            // 
            // txtrusuario
            // 
            this.txtrusuario.BackColor = System.Drawing.Color.Black;
            this.txtrusuario.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtrusuario.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtrusuario.ForeColor = System.Drawing.Color.DimGray;
            this.txtrusuario.Location = new System.Drawing.Point(206, 265);
            this.txtrusuario.Name = "txtrusuario";
            this.txtrusuario.Size = new System.Drawing.Size(189, 25);
            this.txtrusuario.TabIndex = 19;
            this.txtrusuario.Text = "USUARIO";
            this.txtrusuario.UseWaitCursor = true;
            this.txtrusuario.Enter += new System.EventHandler(this.txtrusuario_Enter);
            this.txtrusuario.Leave += new System.EventHandler(this.txtrusuario_Leave);
            // 
            // txtrnombre
            // 
            this.txtrnombre.BackColor = System.Drawing.Color.Black;
            this.txtrnombre.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtrnombre.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtrnombre.ForeColor = System.Drawing.Color.DimGray;
            this.txtrnombre.Location = new System.Drawing.Point(206, 63);
            this.txtrnombre.Name = "txtrnombre";
            this.txtrnombre.Size = new System.Drawing.Size(189, 25);
            this.txtrnombre.TabIndex = 16;
            this.txtrnombre.Text = "NOMBRE";
            this.txtrnombre.UseWaitCursor = true;
            this.txtrnombre.Enter += new System.EventHandler(this.txtrnombre_Enter);
            this.txtrnombre.Leave += new System.EventHandler(this.txtrnombre_Leave);
            // 
            // txtremail
            // 
            this.txtremail.BackColor = System.Drawing.Color.Black;
            this.txtremail.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtremail.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtremail.ForeColor = System.Drawing.Color.DimGray;
            this.txtremail.Location = new System.Drawing.Point(206, 207);
            this.txtremail.Name = "txtremail";
            this.txtremail.Size = new System.Drawing.Size(189, 25);
            this.txtremail.TabIndex = 17;
            this.txtremail.Text = "EMAIL";
            this.txtremail.UseWaitCursor = true;
            this.txtremail.Enter += new System.EventHandler(this.txtremail_Enter);
            this.txtremail.Leave += new System.EventHandler(this.txtremail_Leave);
            // 
            // txtrapellido
            // 
            this.txtrapellido.BackColor = System.Drawing.Color.Black;
            this.txtrapellido.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtrapellido.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtrapellido.ForeColor = System.Drawing.Color.DimGray;
            this.txtrapellido.Location = new System.Drawing.Point(206, 106);
            this.txtrapellido.Name = "txtrapellido";
            this.txtrapellido.Size = new System.Drawing.Size(189, 25);
            this.txtrapellido.TabIndex = 18;
            this.txtrapellido.Text = "APELLIDO";
            this.txtrapellido.UseWaitCursor = true;
            this.txtrapellido.Enter += new System.EventHandler(this.txtrapellido_Enter);
            this.txtrapellido.Leave += new System.EventHandler(this.txtrapellido_Leave);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.Highlight;
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(200, 552);
            this.panel2.TabIndex = 25;
            this.panel2.UseWaitCursor = true;
            // 
            // btnminimizar
            // 
            this.btnminimizar.Location = new System.Drawing.Point(752, 12);
            this.btnminimizar.Name = "btnminimizar";
            this.btnminimizar.Size = new System.Drawing.Size(15, 15);
            this.btnminimizar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.btnminimizar.TabIndex = 27;
            this.btnminimizar.TabStop = false;
            // 
            // btncerrar
            // 
            this.btncerrar.Location = new System.Drawing.Point(773, 12);
            this.btncerrar.Name = "btncerrar";
            this.btncerrar.Size = new System.Drawing.Size(15, 15);
            this.btncerrar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.btncerrar.TabIndex = 26;
            this.btncerrar.TabStop = false;
            // 
            // txtrtelef
            // 
            this.txtrtelef.BackColor = System.Drawing.Color.Black;
            this.txtrtelef.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtrtelef.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtrtelef.ForeColor = System.Drawing.Color.DimGray;
            this.txtrtelef.Location = new System.Drawing.Point(206, 154);
            this.txtrtelef.Name = "txtrtelef";
            this.txtrtelef.Size = new System.Drawing.Size(189, 25);
            this.txtrtelef.TabIndex = 28;
            this.txtrtelef.Text = "TELEFONO";
            this.txtrtelef.UseWaitCursor = true;
            this.txtrtelef.Enter += new System.EventHandler(this.txtrtele);
            this.txtrtelef.Leave += new System.EventHandler(this.txtrtelef_Leave);
            // 
            // Registro
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(800, 552);
            this.Controls.Add(this.txtrtelef);
            this.Controls.Add(this.btnminimizar);
            this.Controls.Add(this.btncerrar);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtrconficontraseña);
            this.Controls.Add(this.txtrcontraseña);
            this.Controls.Add(this.txtrusuario);
            this.Controls.Add(this.txtrnombre);
            this.Controls.Add(this.txtremail);
            this.Controls.Add(this.txtrapellido);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Registro";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Registro";
            ((System.ComponentModel.ISupportInitialize)(this.btnminimizar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btncerrar)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtrconficontraseña;
        private System.Windows.Forms.TextBox txtrcontraseña;
        private System.Windows.Forms.TextBox txtrusuario;
        private System.Windows.Forms.TextBox txtrnombre;
        private System.Windows.Forms.TextBox txtremail;
        private System.Windows.Forms.TextBox txtrapellido;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox btnminimizar;
        private System.Windows.Forms.PictureBox btncerrar;
        private System.Windows.Forms.TextBox txtrtelef;
    }
}