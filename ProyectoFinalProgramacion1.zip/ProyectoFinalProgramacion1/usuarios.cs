﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;


namespace ProyectoFinalProgramacion1
{
    public partial class usuarios : Form
    {
        public usuarios()
        {
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Inicio home = new Inicio();
            home.Show();
            this.Hide();
        }

        static string conexion = "SERVER=127.0.0.1;PORT=3306;DATABASE=userdatabase;UID=root;PASWORD=;";
        MySqlConnection loginconexion= new MySqlConnection(conexion);

        public DataTable llenar_grid()
        {
            loginconexion.Open();
            DataTable dt = new DataTable();
            string llenar = "select nombre,apellido,telefono,email,usuario from usuarios";
            MySqlCommand cmd = new MySqlCommand(llenar, loginconexion);
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            da.Fill(dt);
            loginconexion.Close();

            return dt;
        }



        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                txtunombre.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
                txtuapellido.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
                txtutele.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
                txtuemail.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
                txtuusuario.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
            }
            catch
            {

            }
        }

        private void usuarios_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = llenar_grid();
        }

        private void txtunombre_Enter(object sender, EventArgs e)
        {
            if (txtunombre.Text == "NOMBRE")
            {
                txtunombre.Text = "";
            }
        }

        private void txtunombre_Leave(object sender, EventArgs e)
        {
            if (txtunombre.Text == "")
            {
                txtunombre.Text = "NOMBRE";
            }
        }

        private void txtuapellido_Enter(object sender, EventArgs e)
        {
            if (txtuapellido.Text == "APELLIDO")
            {
                txtuapellido.Text = "";
            }
        }

        private void txtuapellido_Leave(object sender, EventArgs e)
        {
            if (txtuapellido.Text=="")
            {
                txtuapellido.Text = "APELLIDO";
            }
        }

        private void txtutele_Enter(object sender, EventArgs e)
        {
            if (txtutele.Text == "TELEFONO")
            {
                txtutele.Text = "";
            }
        }

        private void txtutele_Leave(object sender, EventArgs e)
        {
            if (txtutele.Text == "")
            {
                txtutele.Text = "TELEFONO";
            }
        }

        private void txtuemail_Enter(object sender, EventArgs e)
        {
            if (txtuemail.Text == "EMAIL")
            {
                txtuemail.Text = "";
;            }
        }

        private void txtuemail_Leave(object sender, EventArgs e)
        {
            if (txtuemail.Text == "")
            {
                txtuemail.Text = "EMAIL";
            }
        }

        private void txtuusuario_Enter(object sender, EventArgs e)
        {
            if (txtuusuario.Text == "USUARIO")
            {
                txtuusuario.Text = "";
            }
        }

        private void txtuusuario_Leave(object sender, EventArgs e)
        {
            if (txtuusuario.Text == "")
            {
                txtuusuario.Text = "USUARIO";
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            loginconexion.Open();
            string querymodificar = "UPDATE usuarios SET nombre=@nombre,apellido=@apellido,telefono=@telefono,email=@email,usuario=@usuario WHERE usuario=@usuario";
            MySqlCommand cmd = new MySqlCommand(querymodificar, loginconexion);
            cmd.Parameters.AddWithValue("@nombre", txtunombre.Text);
            cmd.Parameters.AddWithValue("@apellido", txtuapellido.Text);
            cmd.Parameters.AddWithValue("@telefono", txtutele.Text);
            cmd.Parameters.AddWithValue("@email", txtuemail.Text);
            cmd.Parameters.AddWithValue("@usuario", txtuusuario.Text);

            cmd.ExecuteNonQuery();

            loginconexion.Close();
            MessageBox.Show("Los datos han sido actualizados correctamente");
            dataGridView1.DataSource = llenar_grid();

            txtunombre.Text = "NOMBRE";
            txtuapellido.Text = "APELLIDO";
            txtuemail.Text = "EMAIL";
            txtutele.Text = "TELEFONO";
            txtuusuario.Text = "USUARIO";




        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            loginconexion.Open();
            string queryeliminar = "DELETE FROM usuarios WHERE nombre=@nombre";
            MySqlCommand cmd = new MySqlCommand(queryeliminar, loginconexion);
            cmd.Parameters.AddWithValue("@nombre", txtunombre.Text);

            cmd.ExecuteNonQuery();

            loginconexion.Close();

            MessageBox.Show("Se han eliminado correctamente los datos");

            dataGridView1.DataSource = llenar_grid();

            txtunombre.Text = "NOMBRE";
            txtuapellido.Text = "APELLIDO";
           
            txtutele.Text = "TELEFONO";
            txtuemail.Text = "EMAIL";
            txtuusuario.Text = "USUARIO";


        }
    }
}
