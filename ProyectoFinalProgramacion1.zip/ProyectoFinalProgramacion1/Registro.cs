﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace ProyectoFinalProgramacion1
{
    public partial class Registro : Form
    {
        public Registro()
        {
            InitializeComponent();
        }
       


        private void txtrcontraseña_Enter(object sender, EventArgs e)
        {
            if (txtrcontraseña.Text=="CONTRASEÑA")
            {
                txtrcontraseña.Text = "";
                txtrcontraseña.UseSystemPasswordChar = true;
            }
        }

        private void txtrcontraseña_Leave(object sender, EventArgs e)
        {
            if (txtrcontraseña.Text=="")
            {
                txtrcontraseña.Text = "CONTRASEÑA";
                txtrcontraseña.UseSystemPasswordChar = false;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 login = new Form1();
            login.Show();
            this.Hide();
        }

        private void txtrnombre_Enter(object sender, EventArgs e)
        {
            if (txtrnombre.Text=="NOMBRE")
            {
                txtrnombre.Text = "";
            }
        }

        private void txtrnombre_Leave(object sender, EventArgs e)
        {
            if (txtrnombre.Text == "")
            {
                txtrnombre.Text = "NOMBRE";
            }
        }

        private void txtrapellido_Enter(object sender, EventArgs e)
        {
            if (txtrapellido.Text == "APELLIDO")
            {
                txtrapellido.Text = "";
            }
        }

        private void txtrapellido_Leave(object sender, EventArgs e)
        {
            if (txtrapellido.Text == "")
            {
                txtrapellido.Text = "APELLIDO";

            }
        }

        private void txtremail_Enter(object sender, EventArgs e)
        {
            if (txtremail.Text == "EMAIL")
            {
                txtremail.Text = "";
            }
        }

        private void txtremail_Leave(object sender, EventArgs e)
        {
            if (txtremail.Text == "")
            {
                txtremail.Text = "EMAIL";
            }
        }

        private void txtrusuario_Enter(object sender, EventArgs e)
        {
            if (txtrusuario.Text == "USUARIO")
            {
                txtrusuario.Text = "";
            }
        }

        private void txtrusuario_Leave(object sender, EventArgs e)
        {
            if (txtrusuario.Text == "")
            {
                txtrusuario.Text = "USUARIO";
            }
        }

        private void txtrconficontraseña_Enter(object sender, EventArgs e)
        {
            if(txtrconficontraseña.Text=="CONFIRMAR CONTRASEÑA")
            {
                txtrconficontraseña.Text = "";
                txtrconficontraseña.UseSystemPasswordChar = true;
            }
        }

        private void txtrconficontraseña_Leave(object sender, EventArgs e)
        {
            if (txtrconficontraseña.Text == "")
            {
                txtrconficontraseña.Text = "CONFIRMAR CONTRASEÑA";
                txtrconficontraseña.UseSystemPasswordChar = false;
            }
        }

        Form1 login = new Form1();
        static string conexion = "SERVER=127.0.0.1;PORT=3306;DATABASE=userdatabase;UID=root;PASWORD=;";
        MySqlConnection loginconexion = new MySqlConnection(conexion);
        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                if(txtrconficontraseña.Text!=txtrcontraseña.Text)
                {
                    MessageBox.Show("Las contraseñas no coinciden, intente nuevamente");
                    txtrcontraseña.Text = "CONTRASEÑA";
                    txtrconficontraseña.Text = "CONFIRMAR CONTRASEÑA";
                    txtrconficontraseña.UseSystemPasswordChar = false;
                    txtrcontraseña.UseSystemPasswordChar = false;
                }
                else
                {
                    loginconexion.Open();
                    string insertar = "INSERT INTO userdatabase.usuarios (nombre,apellido,email,telefono,usuario,contraseña)VALUES(@nombre,@apellido,@telefono,@email,@usuario,@contraseña)";
                    MySqlCommand cmd = new MySqlCommand(insertar, loginconexion);

                    cmd.Parameters.AddWithValue("@nombre", txtrnombre.Text);
                    cmd.Parameters.AddWithValue("@apellido", txtrapellido.Text);
                    cmd.Parameters.AddWithValue("telefono", txtrtelef.Text);
                    cmd.Parameters.AddWithValue("@usuario", txtrusuario.Text);
                    cmd.Parameters.AddWithValue("@email", txtremail.Text);
                    cmd.Parameters.AddWithValue("@contraseña", txtrcontraseña.Text);
                    cmd.ExecuteNonQuery();

                    loginconexion.Close();

                    MessageBox.Show("Se agregó correctamente");
                    login.Show();
                    this.Hide();
                }

            }
            catch (Exception Error)
            {
                MessageBox.Show(Error.Message);

            }
        }

        private void textBox1_Enter(object sender, EventArgs e)
        {

        }

        private void txtrtele(object sender, EventArgs e)
        {
            if (txtrtelef.Text == "TELEFONO")
            {
                txtrtelef.Text = "";
            }
        }

        private void txtrtelef_Leave(object sender, EventArgs e)
        {
            if (txtrtelef.Text == "")
            {
                txtrtelef.Text = "TELEFONO";
            }
        }
    }
}
