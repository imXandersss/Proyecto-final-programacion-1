﻿
namespace ProyectoFinalProgramacion1
{
    partial class usuarios
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button4 = new System.Windows.Forms.Button();
            this.txtuusuario = new System.Windows.Forms.TextBox();
            this.txtunombre = new System.Windows.Forms.TextBox();
            this.txtuapellido = new System.Windows.Forms.TextBox();
            this.txtutele = new System.Windows.Forms.TextBox();
            this.txtuemail = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.button1 = new System.Windows.Forms.Button();
            this.panel2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.Highlight;
            this.panel2.Controls.Add(this.button4);
            this.panel2.Controls.Add(this.txtuusuario);
            this.panel2.Controls.Add(this.txtunombre);
            this.panel2.Controls.Add(this.txtuapellido);
            this.panel2.Controls.Add(this.txtutele);
            this.panel2.Controls.Add(this.txtuemail);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(200, 560);
            this.panel2.TabIndex = 26;
            this.panel2.UseWaitCursor = true;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            this.button4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.ForeColor = System.Drawing.Color.LightGray;
            this.button4.Location = new System.Drawing.Point(25, 517);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(137, 31);
            this.button4.TabIndex = 17;
            this.button4.Text = "VOLVER";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.UseWaitCursor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // txtuusuario
            // 
            this.txtuusuario.BackColor = System.Drawing.SystemColors.Highlight;
            this.txtuusuario.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtuusuario.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtuusuario.ForeColor = System.Drawing.Color.Black;
            this.txtuusuario.Location = new System.Drawing.Point(11, 305);
            this.txtuusuario.Name = "txtuusuario";
            this.txtuusuario.Size = new System.Drawing.Size(189, 25);
            this.txtuusuario.TabIndex = 13;
            this.txtuusuario.Text = "USUARIO";
            this.txtuusuario.UseWaitCursor = true;
            this.txtuusuario.Enter += new System.EventHandler(this.txtuusuario_Enter);
            this.txtuusuario.Leave += new System.EventHandler(this.txtuusuario_Leave);
            // 
            // txtunombre
            // 
            this.txtunombre.BackColor = System.Drawing.SystemColors.Highlight;
            this.txtunombre.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtunombre.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtunombre.ForeColor = System.Drawing.Color.Black;
            this.txtunombre.Location = new System.Drawing.Point(12, 108);
            this.txtunombre.Name = "txtunombre";
            this.txtunombre.Size = new System.Drawing.Size(189, 25);
            this.txtunombre.TabIndex = 12;
            this.txtunombre.Text = "NOMBRE";
            this.txtunombre.UseWaitCursor = true;
            this.txtunombre.Enter += new System.EventHandler(this.txtunombre_Enter);
            this.txtunombre.Leave += new System.EventHandler(this.txtunombre_Leave);
            // 
            // txtuapellido
            // 
            this.txtuapellido.BackColor = System.Drawing.SystemColors.Highlight;
            this.txtuapellido.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtuapellido.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtuapellido.ForeColor = System.Drawing.Color.Black;
            this.txtuapellido.Location = new System.Drawing.Point(12, 149);
            this.txtuapellido.Name = "txtuapellido";
            this.txtuapellido.Size = new System.Drawing.Size(189, 25);
            this.txtuapellido.TabIndex = 11;
            this.txtuapellido.Text = "APELLIDO";
            this.txtuapellido.UseWaitCursor = true;
            this.txtuapellido.Enter += new System.EventHandler(this.txtuapellido_Enter);
            this.txtuapellido.Leave += new System.EventHandler(this.txtuapellido_Leave);
            // 
            // txtutele
            // 
            this.txtutele.BackColor = System.Drawing.SystemColors.Highlight;
            this.txtutele.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtutele.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtutele.ForeColor = System.Drawing.Color.Black;
            this.txtutele.Location = new System.Drawing.Point(12, 196);
            this.txtutele.Name = "txtutele";
            this.txtutele.Size = new System.Drawing.Size(189, 25);
            this.txtutele.TabIndex = 10;
            this.txtutele.Text = "TELEFONO";
            this.txtutele.UseWaitCursor = true;
            this.txtutele.Enter += new System.EventHandler(this.txtutele_Enter);
            this.txtutele.Leave += new System.EventHandler(this.txtutele_Leave);
            // 
            // txtuemail
            // 
            this.txtuemail.BackColor = System.Drawing.SystemColors.Highlight;
            this.txtuemail.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtuemail.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtuemail.ForeColor = System.Drawing.Color.Black;
            this.txtuemail.Location = new System.Drawing.Point(12, 247);
            this.txtuemail.Name = "txtuemail";
            this.txtuemail.Size = new System.Drawing.Size(189, 25);
            this.txtuemail.TabIndex = 9;
            this.txtuemail.Text = "EMAIL";
            this.txtuemail.UseWaitCursor = true;
            this.txtuemail.Enter += new System.EventHandler(this.txtuemail_Enter);
            this.txtuemail.Leave += new System.EventHandler(this.txtuemail_Leave);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            this.button2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.ForeColor = System.Drawing.Color.LightGray;
            this.button2.Location = new System.Drawing.Point(241, 485);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(182, 41);
            this.button2.TabIndex = 18;
            this.button2.Text = "MODIFICAR";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.UseWaitCursor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DimGray;
            this.label1.Location = new System.Drawing.Point(348, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(369, 40);
            this.label1.TabIndex = 29;
            this.label1.Text = "GESTIÓN DE USUARIOS";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.dataGridView1);
            this.groupBox1.Location = new System.Drawing.Point(213, 108);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(729, 347);
            this.groupBox1.TabIndex = 30;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "groupBox1";
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(66)))), ((int)(((byte)(91)))));
            this.dataGridView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.HotTrack;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.EnableHeadersVisualStyles = false;
            this.dataGridView1.Location = new System.Drawing.Point(0, 0);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(66)))), ((int)(((byte)(91)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            this.dataGridView1.RowsDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(729, 347);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick_1);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.ForeColor = System.Drawing.Color.LightGray;
            this.button1.Location = new System.Drawing.Point(503, 485);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(182, 41);
            this.button1.TabIndex = 31;
            this.button1.Text = "ELIMINAR";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.UseWaitCursor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // usuarios
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(954, 560);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.panel2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "usuarios";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "usuarios";
            this.Load += new System.EventHandler(this.usuarios_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox txtuusuario;
        private System.Windows.Forms.TextBox txtunombre;
        private System.Windows.Forms.TextBox txtuapellido;
        private System.Windows.Forms.TextBox txtutele;
        private System.Windows.Forms.TextBox txtuemail;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button button1;
    }
}